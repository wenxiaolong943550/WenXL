﻿
namespace MFramework
{
    public interface ICommand
    {
        void Execute();
    }
}

