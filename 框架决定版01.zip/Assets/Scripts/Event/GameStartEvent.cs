﻿using System.Collections;
using System.Collections.Generic;
using MFramework;
using UnityEngine;

public class GameStartEvent : Event<GameStartEvent>
{

}
