﻿using System.Collections;
using System.Collections.Generic;
using MFramework;
using UnityEngine;

public class GameModel
{
    public BindableProperty<int> count = new BindableProperty<int>()
    {
        Value = 0
    };
}
