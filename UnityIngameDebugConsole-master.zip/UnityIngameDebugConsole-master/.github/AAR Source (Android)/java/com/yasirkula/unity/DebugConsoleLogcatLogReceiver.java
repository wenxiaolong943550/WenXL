package com.yasirkula.unity;

/**
 * Created by yasirkula on 7.11.2017.
 */

public interface DebugConsoleLogcatLogReceiver
{
	void OnLogReceived( String log );
}